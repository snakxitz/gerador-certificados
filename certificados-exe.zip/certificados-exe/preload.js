const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('escola', {
  ler: () => ipcRenderer.invoke('ler'),
  salvarFoto: (nome, url) => ipcRenderer.invoke('salvar-foto', nome, url),
  salvarImagem: (chave, url) => ipcRenderer.invoke('salvar-imagem', chave, url),
  salvarConfig: json => ipcRenderer.invoke('salvar-config', json),
  apagarFotos: () => ipcRenderer.invoke('apagar-fotos'),
  abrirPasta: () => ipcRenderer.invoke('abrir-pasta')
});
