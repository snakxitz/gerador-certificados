const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');

// A pasta "dados" fica ao lado do .exe (ou do projeto, quando roda com "npm start").
const base = process.env.PORTABLE_EXECUTABLE_DIR || (app.isPackaged ? path.dirname(process.execPath) : __dirname);
const dados = path.join(base, 'dados');
const sub = d => path.join(dados, d);
['fotos', 'assinaturas', 'logos'].forEach(d => fs.mkdirSync(sub(d), { recursive: true }));

const EXT = /\.(jpe?g|png|webp)$/i;
const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };
const mime = f => MIME[path.extname(f).slice(1).toLowerCase()] || 'application/octet-stream';
const toUrl = f => 'data:' + mime(f) + ';base64,' + fs.readFileSync(f).toString('base64');
const fromUrl = u => Buffer.from(String(u).split(',')[1] || '', 'base64');
const safe = n => path.basename(String(n)).replace(/[\\/:*?"<>|]/g, '_');
// chave da página -> [pasta, nome do arquivo sem extensão]
const IMG = { s1: ['assinaturas', 'direcao'], s2: ['assinaturas', 'monitor'], l1: ['logos', 'colegio'], l2: ['logos', 'governo'] };

ipcMain.handle('ler', () => {
  const fotos = fs.readdirSync(sub('fotos')).filter(f => EXT.test(f))
    .map(f => ({ nome: f, url: toUrl(path.join(sub('fotos'), f)) }));
  const imagens = {};
  for (const k in IMG) {
    const [dir, nome] = IMG[k];
    const f = fs.readdirSync(sub(dir)).find(x => EXT.test(x) && path.parse(x).name.toLowerCase() === nome);
    if (f) imagens[k] = toUrl(path.join(sub(dir), f));
  }
  let config = null;
  try { config = JSON.parse(fs.readFileSync(path.join(dados, 'config.json'), 'utf8')); } catch (e) {}
  return { fotos, imagens, config };
});
ipcMain.handle('salvar-foto', (_e, nome, url) => {
  fs.writeFileSync(path.join(sub('fotos'), safe(nome).replace(/ /g, '_') + '.jpg'), fromUrl(url));
});
ipcMain.handle('salvar-imagem', (_e, chave, url) => {
  if (!IMG[chave]) return;
  const [dir, nome] = IMG[chave];
  for (const x of fs.readdirSync(sub(dir))) if (path.parse(x).name.toLowerCase() === nome) fs.unlinkSync(path.join(sub(dir), x));
  fs.writeFileSync(path.join(sub(dir), nome + '.png'), fromUrl(url));
});
ipcMain.handle('salvar-config', (_e, json) => { fs.writeFileSync(path.join(dados, 'config.json'), String(json)); });
ipcMain.handle('apagar-fotos', () => { for (const f of fs.readdirSync(sub('fotos'))) fs.unlinkSync(path.join(sub('fotos'), f)); });
ipcMain.handle('abrir-pasta', () => shell.openPath(dados));

app.whenReady().then(() => {
  const win = new BrowserWindow({
    width: 1400, height: 900, autoHideMenuBar: true, title: 'Certificados',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.removeMenu();
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
});
app.on('window-all-closed', () => app.quit());
