// Copia fontes e a biblioteca de PDF para dentro do programa, para ele funcionar sem internet.
const fs = require('fs'), path = require('path');
const nm = p => path.join(__dirname, '..', 'node_modules', p);
const out = p => path.join(__dirname, '..', 'app', p);
const itens = [
  ['jspdf/dist/jspdf.umd.min.js', 'vendor/jspdf.umd.min.js'],
  ['@fontsource/caladea/files/caladea-latin-400-normal.woff2', 'fonts/caladea-latin-400-normal.woff2'],
  ['@fontsource/caladea/files/caladea-latin-700-normal.woff2', 'fonts/caladea-latin-700-normal.woff2'],
  ['@fontsource/open-sans/files/open-sans-latin-700-normal.woff2', 'fonts/open-sans-latin-700-normal.woff2'],
  ['@fontsource/caveat-brush/files/caveat-brush-latin-400-normal.woff2', 'fonts/caveat-brush-latin-400-normal.woff2']
];
let erro = false;
for (const [de, para] of itens) {
  if (!fs.existsSync(nm(de))) { console.error('NAO ENCONTRADO: node_modules/' + de); erro = true; continue; }
  fs.mkdirSync(path.dirname(out(para)), { recursive: true });
  fs.copyFileSync(nm(de), out(para));
}
if (erro) { console.error('\nFalta algum arquivo. Rode "npm install" de novo e confira a internet.'); process.exit(1); }
console.log('Fontes e biblioteca de PDF copiadas.');
