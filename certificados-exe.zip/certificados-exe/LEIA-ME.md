# Certificados — programa para Windows

Este projeto gera o arquivo **Certificados.exe**. Você faz isso **uma vez**, num computador com internet.

## 1. Preparar (uma vez, no seu computador)
1. Instale o Node.js (versão LTS) em https://nodejs.org
2. Abra a pasta deste projeto, clique na barra de endereço do Explorador, digite `cmd` e tecle Enter.
3. Rode: `npm install` (demora alguns minutos).

## 2. Testar sem gerar o .exe
`npm start` abre o programa numa janela. Use para conferir antes de gerar.

## 3. Gerar o .exe
`npm run build`
O arquivo aparece em `dist/Certificados.exe`. É um arquivo único, que não precisa de instalação nem de internet.

## 4. Entregar para a escola
Copie `Certificados.exe` para uma pasta do computador da escola, por exemplo `C:\Certificados`.
Na primeira abertura o programa cria, ao lado dele, a pasta **dados** com:

- `dados/fotos/` — uma foto por aluno, com o nome do aluno no arquivo (ex.: `ANA LAURA DE OLIVEIRA.jpg`)
- `dados/assinaturas/` — `direcao.png` e `monitor.png`
- `dados/logos/` — `colegio.png` e `governo.png` (se faltarem, vale o logo que já vem no programa)
- `dados/config.json` — lista de alunos e textos (o programa grava sozinho)

Ao abrir, o programa carrega tudo da pasta `dados`. Para outro computador, copie o `.exe` e a pasta `dados` juntos (por pendrive ou Google Drive).

## Avisos
- O Windows pode mostrar "O Windows protegeu seu computador" (SmartScreen), porque o programa não tem assinatura digital paga. Clique em "Mais informações" e "Executar assim mesmo". Antivírus também podem reclamar de programas novos.
- Se `npm install` ou `npm run build` mostrar erro, copie a mensagem completa para pedir ajuda.
- Não vá mexer na pasta `dados` com o programa aberto, e mantenha cópia das fotos originais.
